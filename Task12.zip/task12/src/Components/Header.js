import React from "react";

class Header extends React.Component {

    render() {

        return (
            <div>
                <h1 className="title">www.Weather_Man.co.za</h1>
            </div>
        )
    }
}

export default Header;